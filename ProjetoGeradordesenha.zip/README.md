# Cofre — Gerador de Senhas

App de desktop (Electron) para gerar senhas aleatórias localmente, com variações
baseadas em palavras/temas de interesse.

## O que tem em cada arquivo

- `app/index.html` — o app em si (HTML + CSS + JS, tudo em um arquivo). É o mesmo
  código que roda na versão web.
- `main.js` — processo principal do Electron: abre uma janela de desktop e carrega
  o `app/index.html` dentro dela.
- `package.json` — dependências e configuração de build (Electron + electron-builder).

## Rodar em modo desenvolvimento

Pré-requisito: [Node.js](https://nodejs.org) instalado (versão 18 ou mais recente).

```bash
npm install
npm start
```

Isso abre o app numa janela própria de desktop — não é uma aba de navegador,
mas usa a mesma tecnologia (HTML/CSS/JS) por baixo.

## Gerar o executável (instalador)

```bash
npm run build
```

O `electron-builder` gera o instalador para o seu sistema operacional dentro da
pasta `dist/`:
- Windows → instalador `.exe` (NSIS)
- macOS → `.dmg`
- Linux → `.AppImage`

Para gerar o executável de um SO diferente do seu (ex: `.exe` a partir do Linux),
pode ser necessário rodar em uma máquina com aquele sistema ou usar CI (veja
seção abaixo).

## Subir para o GitHub

```bash
git init
git add .
git commit -m "primeira versão do app"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```

`node_modules/` e `dist/` já estão no `.gitignore`, então não vão pro repositório
— só o código-fonte.

## Sobre a feature "Buscar referências"

Essa parte pergunta a um modelo de IA por palavras associadas a um tema. Ela só
funciona quando o app está rodando publicado como Artifact dentro do claude.ai,
porque depende de uma conexão que só existe nesse ambiente. Rodando como app de
desktop (Electron) ou como arquivo `.html` local, essa feature específica mostra
o aviso de "sem conexão disponível" — mas o gerador de senha e as variações
locais continuam funcionando normalmente, sem precisar de internet.

## Gerar o .exe automaticamente pelo GitHub (sem precisar de Windows)

Já incluí o workflow `.github/workflows/build.yml`. Depois que você subir o
projeto pro GitHub (seção acima), ele roda sozinho a cada `push` na branch
`main` — o GitHub compila o app numa máquina Windows na nuvem, sem você
precisar instalar nada.

Pra pegar o `.exe` gerado:

1. No repositório, clique na aba **Actions**.
2. Abra a execução mais recente do workflow **Build**.
3. Role até **Artifacts** e baixe **cofre-gerador-senhas-windows** — é um
   `.zip` contendo o instalador `.exe`.

Se quiser rodar manualmente sem esperar um push, use o botão **Run workflow**
na aba Actions (isso funciona graças ao `workflow_dispatch` no arquivo).
